package cn.kis2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import Pojo.User;

import javax.servlet.http.HttpServletRequest;

public class RequestController {
    @RequestMapping("/simpleParam")
    public String simpleParam(HttpServletRequest request) {
        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");

        int age = Integer.parseInt(ageStr);

        System.out.println(name + ":" + age);
        return "OK";
    }


    //2.实体参数

    @RequestMapping("/simplePojo")
    public String simplePojo(User user){
        System.out.println(user);
        return "OK";
    }
}
