package Pojo;

public class User {
    private String uname;
    private Integer age;

    public String getName() {
        return uname;
    }

    public void setName(String uname) {
        this.uname = User.this.uname;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "User{" +
                "uname='" + uname + '\'' +
                ", age=" + age +
                '}';
    }
}
